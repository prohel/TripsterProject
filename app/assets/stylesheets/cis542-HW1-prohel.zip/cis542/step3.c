
#include "prime.h"

int main(int argc, char **argv) {
	if (argc < 2) {
		printf("No argument passed");
		return 1;
	}
	else {
		int i;
		for (i = 1; i <= atoi(argv[1]) ; i++)
			if (is_prime(i))
				printf("%d; ", i);
	}
	return 0;
}