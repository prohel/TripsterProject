

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#define MAX_LEN 255
/* copy file byte by byte */

void print_comparison_message(int a, int b);
double diff_time(time_t s, time_t e);

/*I chose to use atoi to convert the input to integer because it is simple
I am warning the user at the beginning that non-digit will result in a 0*/

int main () {
  time_t start, end;
  time(&start);
  printf("\nStart time: %s\n\n",asctime(localtime(&start)));

  //generating random number
  srand(time(NULL));
  int r = rand() % 101;

   int count = 0;
   printf ("--*** Any non-digit input will be converted to 0 ***--\n") ;
    char *strnum = (char*) malloc (sizeof(char)*MAX_LEN);
    if (strnum == NULL) {
        return 1;
    }
    int num = -1;

    //main loop asking the user too guess the number
    while (count < 10 && num != r) {
      printf ("Please guess what the value of the generated number is: \n") ;
      fgets (strnum, sizeof(char)*MAX_LEN, stdin);
      int len = strlen(strnum);
      if ((len>0) && (strnum[len - 1] == '\n')) {
          strnum[len - 1] = '\0';
      }
      num = atoi(strnum);
      print_comparison_message(num, r);
      count++;
    }

    if (count == 10)
        printf("You lost! The generated number was: %d", r);
    else
      printf("Congratulations! You found the generated number!\n\n");

    time(&end);
    printf("Ending time: %s\n",asctime(localtime(&start)));
    printf("Time elapsed: %f seconds\n", diff_time(start, end));
    return 0 ; 
}

void print_comparison_message(a, b) {
  if (b > a)
    printf("The generated number is higher than that, please try again.\n");
  else if (b < a)
    printf("The generated number is lower than that, please try again.\n");
}

double diff_time(time_t s, time_t e) {
  return difftime(e, s);
}