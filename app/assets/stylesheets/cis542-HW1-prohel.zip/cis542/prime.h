#include <stdio.h>
#include <stdlib.h>

int is_prime(int n);
