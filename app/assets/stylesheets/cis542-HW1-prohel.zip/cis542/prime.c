
int is_prime(int n){
	 int k, limit;
  if (n==2)
	return 1;
  //first simple test, if it is even it is not prime
  if (n % 2 == 0)
	return 0;
	 limit = n/2;
  /*if it is not even we have to iterate through the odd numbers
  to look for factors. See below why we can limit ourselves to k < n/2*/
  for( k = 3; k <= limit; k+=2)
  	//if we find a factor, our number is not prime
	if ( n % k == 0)
	 return 0;
  //if we get here we made sure there is no factor greater 1 so our number is prime
  return 1;
}

/*We limit ourselves to n/2 because we are looking for k such that there exists
p and k*p = n. p > 2 because we took care of the even number. so k < n/2*/