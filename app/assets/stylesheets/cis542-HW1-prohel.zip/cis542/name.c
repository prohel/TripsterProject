

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LEN 1024

int main () {

   printf ("Please enter your full name: ") ;
   char *name = (char*) malloc (sizeof(char)*MAX_LEN);
    if (name == NULL) {
        return 1;
    }
    // Gets the name
    fgets (name, sizeof(char)*MAX_LEN, stdin);

    // Removes newline at the end, if there any.
    int len = strlen(name);
    if ((len>0) && (name[len - 1] == '\n')) {
        name[len - 1] = '\0';
    }
    char *original = name;
    //a temp on the stack was not working so I am creating it on the heap
    char *temp = (char*) malloc(sizeof(char));
    char *t = name;
    
    //Now let's reverse the full name
    while (*t != '\0') {t++;}
    t--;
    while (t > name) {
      *temp = *name;
      *name = *t;
      *t = *temp; 
      t-=1; name+=1;
    }

    printf("The total length of the name is: %d, the reverse is: %s\n", len-1, original);
    free(original);
    free(temp);
    return 0 ; 
}


 
